import express from 'express';

const app = express();
const PORT = 4000;

app.get("/", (req, resp) => {
  resp.send('Express App is working!');
});

app.listen(4000, () => {
  console.log(`listening on port ${PORT}`)
});